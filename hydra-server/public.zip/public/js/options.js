Tone.Transport.bpm.value = 160

var pulseOptions = {
  oscillator: {
  	type: 'pulse'
  },
  envelope: {
    release: 0.07
  }
}

var triangleOptions = {
  oscillator: {
  	type: 'triangle'
  },
  envelope: {
    release: 0.07
  }
}

var squareOptions = {
  oscillator: {
  	type: 'square'
  },
  envelope: {
    release: 0.07
  }
}
